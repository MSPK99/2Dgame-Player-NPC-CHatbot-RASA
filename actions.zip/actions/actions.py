# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message(text="Hello World!")
#
#         return []

from typing import Any, Text, Dict, List
from random import choice
from rasa_sdk import Action, Tracker
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher


class ActionDefaultFallback(Action):
    def name(self) -> Text:
        return "action_default_fallback"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # Get the number of times the fallback action has been called
        fallback_count = tracker.get_slot("fallback_count")
        if fallback_count is None:
            fallback_count = 0
        else:
            fallback_count = int(fallback_count)

        # Define sarcastic and arrogant responses
        sarcastic_responses = [
            "Wow, you're really testing my patience.",
            "Can you make your question any more vague?",
            "I'm amazed by your ability to confuse me.",
            "You must be a master at being unclear.",
            "Keep trying, maybe one day you'll make sense."
            "Oh, you're being intentionally vague. How clever."
            "I see we're playing the 'confuse the bot' game again."
            "Congratulations, you've managed to stump me once more."
            "I'm sorry, did you want an actual response or just to waste my time?"
            "Let me guess, you're going to ask something completely unrelated again."
        ]

        arrogant_responses = [
            "Clearly, you need more practice in asking questions.",
            "I'm not here to hold your hand through this.",
            "Maybe try using your brain next time?",
            "I'm beginning to doubt your intelligence.",
            "How about you take a moment to think before speaking?"
            "I'm starting to think I'm too advanced for you."
            "Perhaps I should dumb myself down to your level for better communication."
            "I can't help but feel like you're holding me back."
            "You're lucky I'm even bothering to respond to you."
            "If only you were as intelligent as you think you are."
        ]

        # Select the response based on the current fallback count

        response_message = ""
        if fallback_count % 2 == 0:
            response_message = choice(arrogant_responses)
        else:
            response_message = choice(sarcastic_responses)

        # Increment the fallback count for the next fallback action
        fallback_count += 1

        # Set the updated fallback count in the tracker
        # tracker.set_slot("fallback_count", fallback_count)
        # Set the updated fallback count in the tracker
        events = [SlotSet("fallback_count", fallback_count)]
        # Send the selected response
        dispatcher.utter_message(response_message)

        return events


class ActionRespondToGreet(Action):
    def name(self) -> Text:
        return "action_respond_to_greet"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        # Dynamically select a greeting response
        dispatcher.utter_message(response="utter_greet")
        return []


class ActionRespondToMoodGreat(Action):
    def name(self) -> Text:
        return "action_respond_to_mood_great"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        dispatcher.utter_message(response="utter_mood_great")
        return []


class ActionRespondToSmackTalk(Action):
    def name(self):
        return "action_respond_to_smack_talk"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_smack_talk")
        return []






class ActionRespondToCursing(Action):
    def name(self):
        return "action_respond_to_cursing"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_cursing")
        return []

# Custom Action for Overcompetitive
class ActionRespondToOvercompetitive(Action):
    def name(self):
        return "action_respond_to_overcompetitive"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_overcompetitive")
        return []

# Custom Action for Gentle
class ActionRespondToGentle(Action):
    def name(self):
        return "action_respond_to_gentle"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_gentle")
        return []

# Custom Action for Asking Questions
class ActionRespondToAskingQuestions(Action):
    def name(self):
        return "action_respond_to_asking_questions"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_asking_questions")
        return []

# Custom Action for Impatient
class ActionRespondToImpatient(Action):
    def name(self):
        return "action_respond_to_impatient"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_impatient")
        return []

# Custom Action for Aggressive Charge
class ActionRespondToAggressiveCharge(Action):
    def name(self):
        return "action_respond_to_aggressive_charge"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_aggressive_charge")
        return []

# Custom Action for Friendly Greeting
class ActionRespondToFriendlyGreeting(Action):
    def name(self):
        return "action_respond_to_friendly_greeting"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_friendly_greeting")
        return []






# Custom Action for Seeking Forgiveness
class ActionRespondToSeekingForgiveness(Action):
    def name(self):
        return "action_respond_to_seeking_forgiveness"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_seeking_forgiveness")
        return []

# Custom Action for Expressing Enjoyment
class ActionRespondToExpressingEnjoyment(Action):
    def name(self):
        return "action_respond_to_expressing_enjoyment"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_expressing_enjoyment")
        return []

# Custom Action for Expressing Dislike
class ActionRespondToExpressingDislike(Action):
    def name(self):
        return "action_respond_to_expressing_dislike"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_expressing_dislike")
        return []

# Custom Action for Asking About Rules
class ActionRespondToAskingAboutRules(Action):
    def name(self):
        return "action_respond_to_asking_about_rules"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_asking_about_rules")
        return []

# Custom Action for Suggesting An Idea
class ActionRespondToSuggestingAnIdea(Action):
    def name(self):
        return "action_respond_to_suggesting_an_idea"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_suggesting_an_idea")
        return []

# Custom Action for Expressing Curiosity
class ActionRespondToExpressingCuriosity(Action):
    def name(self):
        return "action_respond_to_expressing_curiosity"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_expressing_curiosity")
        return []

# Custom Action for Showing Appreciation
class ActionRespondToShowAppreciation(Action):
    def name(self):
        return "action_respond_to_showing_appreciation"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_showing_appreciation")
        return []

# Custom Action for Expressing Sarcasm
class ActionRespondToExpressingSarcasm(Action):
    def name(self):
        return "action_respond_to_expressing_sarcasm"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_expressing_sarcasm")
        return []

# Custom Action for Expressing Eagerness
class ActionRespondToExpressingEagerness(Action):
    def name(self):
        return "action_respond_to_expressing_eagerness"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_expressing_eagerness")
        return []

# Custom Action for Indicating Confusion About Objectives
class ActionRespondToIndicatingConfusionAboutObjectives(Action):
    def name(self):
        return "action_respond_to_indicating_confusion_about_objectives"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_indicating_confusion_about_objectives")
        return []

# Custom Action for Making Light of Situation
class ActionRespondToMakingLightOfSituation(Action):
    def name(self):
        return "action_respond_to_making_light_of_situation"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_making_light_of_situation")
        return []

# Custom Action for Expressing Need For Break
class ActionRespondToExpressingNeedForBreak(Action):
    def name(self):
        return "action_respond_to_expressing_need_for_break"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_expressing_need_for_break")
        return []

# Custom Action for Acknowledging Risk
class ActionRespondToAcknowledgingRisk(Action):
    def name(self):
        return "action_respond_to_acknowledging_risk"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(response="utter_acknowledging_risk")
        return []

# Note: Continue creating similar actions for all other intents you have listed.
