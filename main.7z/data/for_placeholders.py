import yaml

# Load the YAML file
def load_yaml(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return yaml.safe_load(file)

# Save the YAML file
def save_yaml(data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        yaml.dump(data, file, allow_unicode=True, default_flow_style=False, sort_keys=False)

# The function to replace placeholders in the examples
def replace_placeholders(data, replacements):
    for intent_data in data['nlu']:
        examples = intent_data.get('examples', '')
        if '|' in examples:  # Multiline string indicator in YAML
            new_examples_list = []
            examples_lines = examples.split('\n')[1:]  # Skip the first empty line after '|'
            for line in examples_lines:
                if not line.strip():  # Skip empty lines
                    continue
                # Replace placeholders in this line
                for placeholder, words in replacements.items():
                    if placeholder in line:
                        for word in words:
                            new_examples_list.append(line.replace(placeholder, word))
                        break  # Assume one placeholder per line for simplicity
            # Update the examples with the new list
            new_examples_str = '\n'.join(new_examples_list)
            intent_data['examples'] = f"|\n{new_examples_str}"

    return data

file_path = 'E:/pyhon proj rasa/pythonProjectn/game_project/data/nlu.yml'

# Define your placeholders and their replacements here
replacements = {
    '[Expletive]': ['damn', 'freaking', 'fuck', 'fcking', 'fckin', 'fkn', 'fk', 'shittin', 'shitting'],
}

# Load, replace placeholders, and save the YAML file
nlu_data = load_yaml(file_path)
nlu_data_updated = replace_placeholders(nlu_data, replacements)
save_yaml(nlu_data_updated, file_path)
